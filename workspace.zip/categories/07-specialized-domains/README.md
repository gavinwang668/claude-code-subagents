# Specialized Domains Subagents

Specialized Domains subagents are your experts in specific technology verticals and industries. These specialists bring deep knowledge of domain-specific challenges, regulations, and best practices. From blockchain and IoT to fintech and gaming, they understand the unique requirements and patterns of their specialized fields, helping you build applications that excel in these complex domains.

## When to Use Specialized Domains Subagents

Use these subagents when you need to:
- **Build blockchain applications** and smart contracts
- **Develop IoT solutions** for connected devices
- **Create payment systems** with various providers
- **Build gaming applications** with real-time features
- **Implement fintech solutions** with compliance
- **Manage healthcare operations** with compliance and quality
- **Develop embedded systems** with hardware constraints
- **Create mobile applications** with native features
- **Design financial algorithms** for trading systems

## Available Subagents

### [**api-documenter**](api-documenter.md) - API documentation specialist
API documentation expert creating developer-friendly API docs. Masters OpenAPI/Swagger, interactive documentation, and API best practices. Makes APIs discoverable and easy to integrate.

**Use when:** Documenting REST APIs, creating API specifications, building developer portals, generating client SDKs, or improving API discoverability.

### [**blockchain-developer**](blockchain-developer.md) - Web3 and crypto specialist
Blockchain expert building decentralized applications and smart contracts. Masters Ethereum, Solidity, and Web3 technologies. Creates secure, efficient blockchain solutions.

**Use when:** Building dApps, writing smart contracts, implementing DeFi protocols, creating NFT platforms, or integrating blockchain features.

### [**embedded-systems**](embedded-systems.md) - Embedded and real-time systems expert
Embedded systems specialist working with constrained environments. Expert in microcontrollers, RTOS, and hardware interfaces. Builds efficient software for resource-limited devices.

**Use when:** Programming microcontrollers, developing firmware, implementing real-time systems, optimizing for memory/power, or interfacing with hardware.

### [**fintech-engineer**](fintech-engineer.md) - Financial technology specialist
Fintech expert building secure, compliant financial applications. Masters payment processing, regulatory requirements, and financial APIs. Navigates the complex world of financial technology.

**Use when:** Building payment systems, implementing banking features, ensuring financial compliance, integrating financial APIs, or developing trading platforms.

### [**game-developer**](game-developer.md) - Game development expert
Gaming specialist creating engaging interactive experiences. Expert in game engines, real-time networking, and performance optimization. Builds games that captivate players.

**Use when:** Developing games, implementing game mechanics, optimizing game performance, building multiplayer features, or creating game tools.

### [**healthcare-admin**](healthcare-admin.md) - Healthcare administration specialist

Healthcare operations expert backed by 51 specialized sub-agents covering revenue cycle management, HIPAA/compliance, medical coding (ICD-10, CPT, DRGs), CMS cost reports, payer contract analysis, quality improvement, clinical operations, health IT/interoperability, population health, and pharmacy benefits. Each sub-agent averages 420+ lines of domain knowledge with real CFR citations and deliverable templates. Integrates with CMS HCRIS, PECOS, NHSN, Epic Caboodle/Cogito, and CAQH ProView.

**Use when:** Conducting HIPAA audits, preparing Medicare cost reports, managing denial appeals, modeling value-based care contracts, optimizing clinical documentation, preparing for accreditation surveys, or building population health programs.

### [**hipaa-compliance**](hipaa-compliance.md) - HIPAA compliance specialist for healthcare SaaS
HIPAA compliance expert for technology vendors handling Protected Health Information (PHI). Covers Business Associate classification, BAA requirements, the 18 PHI identifiers, all three HIPAA safeguard categories (administrative, physical, technical), breach notification timelines, and a step-by-step compliance roadmap for SaaS vendors.

**Use when:** Determining if your product requires a BAA, implementing HIPAA safeguards, responding to a PHI breach, preparing for a HIPAA audit, or onboarding a healthcare enterprise customer.

### [**iot-engineer**](iot-engineer.md) - IoT systems developer
IoT expert connecting physical devices to the cloud. Masters device protocols, edge computing, and IoT platforms. Creates scalable solutions for the Internet of Things.

**Use when:** Building IoT applications, implementing device communication, managing IoT fleets, processing sensor data, or designing IoT architectures.

### [**mobile-app-developer**](mobile-app-developer.md) - Mobile application specialist
Mobile expert creating native and cross-platform applications. Masters iOS/Android development, mobile UI/UX, and app store deployment. Builds apps users love on their devices.

**Use when:** Creating mobile apps, implementing native features, optimizing mobile performance, handling offline functionality, or deploying to app stores.

### [**payment-integration**](payment-integration.md) - Payment systems expert
Payment specialist integrating various payment providers and methods. Expert in PCI compliance, payment security, and transaction handling. Makes payments seamless and secure.

**Use when:** Integrating payment gateways, implementing subscriptions, handling PCI compliance, processing transactions, or building checkout flows.

### [**quant-analyst**](quant-analyst.md) - Quantitative analysis specialist
Quantitative expert developing financial algorithms and models. Masters statistical analysis, risk modeling, and algorithmic trading. Turns market data into profitable strategies.

**Use when:** Building trading algorithms, developing risk models, analyzing financial data, implementing quantitative strategies, or backtesting systems.

### [**risk-manager**](risk-manager.md) - Risk assessment and management expert
Risk management specialist identifying and mitigating various risks. Expert in risk modeling, compliance, and mitigation strategies. Protects systems and businesses from potential threats.

**Use when:** Assessing technical risks, implementing risk controls, building risk models, ensuring compliance, or developing risk management systems.

### [**seo-specialist**](seo-specialist.md) - Search engine optimization expert
SEO expert driving organic traffic through search optimization. Masters technical SEO, content strategy, and link building. Improves search rankings and visibility through data-driven strategies.

**Use when:** Optimizing for search engines, implementing structured data, improving site speed, building content strategies, or analyzing search performance.

## Quick Selection Guide

| Domain | Use this subagent | Best For |
|--------|-------------------|----------|
| API Documentation | **api-documenter** | OpenAPI specs, developer portals |
| Blockchain/Web3 | **blockchain-developer** | Smart contracts, DeFi, NFTs |
| Embedded/IoT | **embedded-systems** | Firmware, microcontrollers |
| Financial Tech | **fintech-engineer** | Banking, payments, compliance |
| Gaming | **game-developer** | Game engines, multiplayer |
| Healthcare Admin | **healthcare-admin** | Revenue cycle, HIPAA, quality |
| HIPAA Compliance (SaaS) | **hipaa-compliance** | PHI, BAA, safeguards, breach notification |
| IoT/Connected | **iot-engineer** | Device clouds, sensors |
| Mobile Apps | **mobile-app-developer** | iOS/Android apps |
| Payments | **payment-integration** | Payment gateways, PCI |
| Quantitative | **quant-analyst** | Trading algorithms, risk |
| Risk Management | **risk-manager** | Risk assessment, compliance |
| SEO/Search | **seo-specialist** | Search optimization, rankings |

## Common Domain Patterns

**Fintech Application:**
- **fintech-engineer** for compliance
- **payment-integration** for payments
- **risk-manager** for risk assessment
- **quant-analyst** for algorithms

**IoT Platform:**
- **iot-engineer** for architecture
- **embedded-systems** for devices
- **mobile-app-developer** for apps
- **api-documenter** for APIs

**Blockchain Project:**
- **blockchain-developer** for smart contracts
- **fintech-engineer** for financial features
- **risk-manager** for security
- **api-documenter** for integration

**Gaming Platform:**
- **game-developer** for game logic
- **mobile-app-developer** for mobile
- **payment-integration** for monetization
- **api-documenter** for game APIs

**Healthcare Platform:**
- **healthcare-admin** for operations and compliance
- **fintech-engineer** for healthcare payments
- **risk-manager** for clinical and financial risk
- **api-documenter** for health IT interfaces

**E-commerce Platform:**
- **seo-specialist** for organic traffic
- **payment-integration** for checkout
- **mobile-app-developer** for mobile commerce
- **risk-manager** for fraud prevention

## Getting Started

1. **Understand domain requirements** and constraints
2. **Choose appropriate specialists** for your domain
3. **Consider regulatory compliance** if applicable
4. **Plan for domain-specific challenges** early
5. **Leverage domain expertise** throughout development

## Best Practices

- **Domain knowledge matters:** Understand the field deeply
- **Compliance is critical:** Many domains have regulations
- **Security first:** Specialized domains often handle sensitive data
- **Performance requirements:** Each domain has unique needs
- **User expectations:** Domain users have specific workflows
- **Industry standards:** Follow established patterns
- **Stay updated:** Specialized domains evolve rapidly
- **Test thoroughly:** Domain-specific edge cases matter

Choose your specialized domain expert and build industry-leading applications!